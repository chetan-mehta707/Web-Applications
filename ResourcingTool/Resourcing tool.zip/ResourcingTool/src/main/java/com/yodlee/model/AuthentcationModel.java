package com.yodlee.model;

public class AuthentcationModel {

	private String message="";

	public AuthentcationModel(String message) {
		this.message = message;
	}

	public AuthentcationModel() {
		
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
